#ifndef CLONE_H
#define CLONE_H

int clone_households(int update, int node_id);

int clone_region(int update, int node_id);

#endif
